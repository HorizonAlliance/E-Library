'use strict';
//#if TRUE
var a;

//#if TRUE
var b;
//#else
var c;
//#endif

var d;
//#else
var e;
//#if TRUE
var f;
//#endif

var g;
//#endif
